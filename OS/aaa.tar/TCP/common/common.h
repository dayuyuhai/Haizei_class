/*************************************************************************
	> File Name: common.h
	> Author: 
	> Mail: 
	> Created Time: Fri 18 Sep 2020 07:10:47 PM CST
 ************************************************************************/

#ifndef _COMMON_H
#define _COMMON_H

int socket_create(int port);
int socket_connect(char *ip, int port);

#endif
